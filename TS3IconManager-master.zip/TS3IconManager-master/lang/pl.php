<?PHP
$lang = array();
 
$lang['i_inputuid'] = "Wpisz swoje ID (Unique ID) z serwera .";
$lang['i_title'] = "Panel z ikonami";
$lang['i_buttonsend'] = "Szukaj";
 
$lang['f_maxicons'] = "Wybrano za dużo ikon.";
$lang['f_connect'] = "Musisz być na serwerze żeby dokonać operacji.";
$lang['f_connectts'] = "Nie można połączyć się z serwerem TS3.";
$lang['f_uuid'] = "ID (Unique ID) jest nieprawidłowe lub aktualnie nie jesteś na serwerze.";
$lang['f_querydata'] = "Dane dostępu Query są błędne";
$lang['f_banned'] = "Połączenie zostało zablokowanie. Spróbuj ponownie później.";
$lang['f_twoconnect'] = "Ktoś używa Twojego Unique ID w tym momencie. Spróbuj ponownie później.";
$lang['f_perms'] = "Połączenie Query nie ma permisji by wykonać daną operację skryptu.";
$lang['f_derrortitle'] = "Nastąpił nieoczekiwany błąd.";
$lang['f_dmsg'] = "Błąd wiadomości";
$lang['f_dcode'] = "Błąd kodu";
$lang['f_unk'] = "Nieznany błąd lub zła metoda";
$lang['f_msgfailcode'] = "Podany kod nie pasuje";
$lang['f_msgemptysave'] = "Brak zmian do zrobienia";
 
$lang['load'] = "Ładowanie...";
 
$lang['l_idt'] = "Twoje ID";
$lang['l_lastname'] = "Nazwa w użyciu";
$lang['l_checkmsg'] = "To Twój kod weryfikacyjny";
$lang['l_checkalert'] = "Wpisz na dole kod by dokończyć proces";
$lang['l_save'] = "Zapisywanie.";
 
$lang['i_save'] = "Zapisano";
$lang['succes'] = "Ikony dodano prawidłowo";
 
?>