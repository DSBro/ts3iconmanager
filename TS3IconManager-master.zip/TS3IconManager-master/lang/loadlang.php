<?php
/*
*************************************************
/				Autor: Pedro Arenas (Doc)		/
/				Archivo: loadlang.php			/
*************************************************
*/
include './data/config.php';

include './lang/'.$IDIOMA.'.php';

?>