# TS3IconManager
Files to read/Archivos a mirar:

ES: README_ES.md

EN: README_EN.md

#Aviso

Este script queda sin soporte oficial del autor, debido al estado actual del script.
En un futuro planeo lanzar 2 sistemas mas compactos y faciles de manejar para estas tareas.
